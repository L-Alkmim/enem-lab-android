package br.com.enemlab.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Renders official PDF pages with Android PdfRenderer, no Chrome, PDF plugin or external viewer required. */
public final class PdfViewerActivity extends Activity {
    private static final int CHOOSE_PDF=700;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private PdfRenderer pdf;
    private ParcelFileDescriptor handle;
    private ImageView image;
    private TextView pageText,titleText;
    private ProgressBar progress;
    private Button next,prev;
    private int page=0;
    private volatile boolean closed=false;
    private String remote,title;
    private File loadedFile;

    private Button button(String title,Runnable click){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(12);
        b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff35265d));
        b.setOnClickListener(v->click.run());return b;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        remote=getIntent().getStringExtra("pdfUrl");title=getIntent().getStringExtra("title");
        if(title==null)title="Leitor de cadernos";
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff090e1b);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(5,3,5,3);root.addView(top,new LinearLayout.LayoutParams(-1,-2));
        top.addView(button("← Voltar",this::finish));
        titleText=new TextView(this);titleText.setText(title);titleText.setTextColor(Color.WHITE);titleText.setTextSize(13);titleText.setGravity(Gravity.CENTER);
        top.addView(titleText,new LinearLayout.LayoutParams(0,-2,1));
        top.addView(button("Importar PDF",this::choose));
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);root.addView(progress,new LinearLayout.LayoutParams(-1,6));
        image=new ZoomImageView(this);
        image.setBackgroundColor(0xffdbe3ec);
        root.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(6,4,6,4);
        prev=button("◀ Anterior",()->showPage(page-1));nav.addView(prev,new LinearLayout.LayoutParams(0,-2,1));
        pageText=new TextView(this);pageText.setTextColor(Color.WHITE);pageText.setGravity(Gravity.CENTER);pageText.setText("Abrindo PDF…");
        nav.addView(pageText,new LinearLayout.LayoutParams(0,-2,1));
        next=button("Próxima ▶",()->showPage(page+1));nav.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(nav);setContentView(root);
        if(remote!=null)download();else choose();
    }
    private void message(String msg){runOnUiThread(()->Toast.makeText(this,msg,Toast.LENGTH_LONG).show());}
    private void choose(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/pdf");intent.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(intent,CHOOSE_PDF);}catch(Exception e){message("Não foi possível abrir o seletor de PDF");}
    }
    private File directory(){File f=new File(getFilesDir(),"exam_pdfs");if(!f.exists())f.mkdirs();return f;}
    private void download(){
        io.execute(()->{
            HttpURLConnection conn=null;
            try{
                String hash=sha256(remote);File cache=new File(directory(),hash+".pdf");
                if(!cache.exists()||cache.length()<500){
                    conn=(HttpURLConnection)new URL(remote).openConnection();
                    conn.setConnectTimeout(15000);conn.setReadTimeout(45000);
                    if(conn.getResponseCode()!=200)throw new Exception("HTTP "+conn.getResponseCode());
                    File partial=new File(directory(),hash+".partial");
                    try(InputStream in=conn.getInputStream();FileOutputStream out=new FileOutputStream(partial)){
                        byte[] buf=new byte[32768];int n;long total=0;
                        while((n=in.read(buf))!=-1){out.write(buf,0,n);total+=n;if(total>60L*1024*1024)throw new Exception("PDF excede o limite de 60 MB");}
                    }
                    if(!partial.renameTo(cache))throw new Exception("Falha ao armazenar PDF");
                }
                openPdf(cache);
            }catch(Exception e){message("Não foi possível abrir o PDF: "+e.getMessage()+". Você pode importar um PDF já baixado.");runOnUiThread(()->progress.setVisibility(View.INVISIBLE));}
            finally{if(conn!=null)conn.disconnect();}
        });
    }
    private static String sha256(String value)throws Exception{
        byte[] bytes=MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));
        StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format("%02x",b&255));return out.toString();
    }
    private void openPdf(File f)throws Exception{
        if(closed)return;
        if(pdf!=null){pdf.close();pdf=null;}
        if(handle!=null){handle.close();handle=null;}
        handle=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);
        pdf=new PdfRenderer(handle);loadedFile=f;page=0;
        renderPage(0);
    }
    private void showPage(int n){io.execute(()->{if(pdf!=null&&n>=0&&n<pdf.getPageCount())renderPage(n);});}
    private void renderPage(int n){
        try{
            if(closed||pdf==null)return;
            final int count=pdf.getPageCount();
            if(n<0||n>=count)return;
            runOnUiThread(()->progress.setVisibility(View.VISIBLE));
            PdfRenderer.Page paper=pdf.openPage(n);
            try{
                int width=getResources().getDisplayMetrics().widthPixels;
                float scale=Math.min(2.6f,Math.max(1.3f, (width*1.8f)/paper.getWidth()));
                int bw=Math.max(1,Math.round(paper.getWidth()*scale));
                int bh=Math.max(1,Math.round(paper.getHeight()*scale));
                if((long)bw*bh>12000000){float correction=(float)Math.sqrt(12000000.0/(bw*(double)bh));bw=Math.max(1,(int)(bw*correction));bh=Math.max(1,(int)(bh*correction));}
                Bitmap bitmap=Bitmap.createBitmap(bw,bh,Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                paper.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                final int finalN=n;
                runOnUiThread(()->{
                    if(closed){bitmap.recycle();return;}
                    image.setImageBitmap(bitmap);
                    page=finalN;
                    pageText.setText((page+1)+" / "+count);
                    prev.setEnabled(page>0);next.setEnabled(page<count-1);
                    progress.setVisibility(View.INVISIBLE);
                });
            }finally{paper.close();}
        }catch(Exception e){message("Erro ao renderizar página: "+e.getMessage());runOnUiThread(()->progress.setVisibility(View.INVISIBLE));}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==CHOOSE_PDF&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();
            io.execute(()->{
                try{
                    File f=new File(directory(),"importado_"+System.currentTimeMillis()+".pdf");
                    try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(f)){
                        if(in==null)throw new Exception("Não foi possível ler o documento");
                        byte[] buf=new byte[32768];int n;long total=0;
                        while((n=in.read(buf))!=-1){out.write(buf,0,n);total+=n;if(total>60L*1024*1024)throw new Exception("PDF excede 60 MB");}
                    }
                    openPdf(f);
                }catch(Exception e){message("PDF inválido: "+e.getMessage());}
            });
        }
    }
    @Override public void onConfigurationChanged(Configuration configuration){super.onConfigurationChanged(configuration);showPage(page);}
    @Override protected void onDestroy(){
        closed=true;
        io.execute(()->{try{if(pdf!=null)pdf.close();if(handle!=null)handle.close();}catch(Exception ignored){}});
        io.shutdown();super.onDestroy();
    }
    /** Gesture-aware PDF image: 2-finger pinch to zoom, drag for panning, double tap reset. */
    private static final class ZoomImageView extends ImageView {
        private final Matrix matrix=new Matrix();private final PointF last=new PointF();
        private final ScaleGestureDetector detector;
        private float zoom=1f;private boolean drag=false;
        ZoomImageView(Activity c){super(c);setScaleType(ScaleType.FIT_CENTER);
            detector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(ScaleGestureDetector d){
                    float target=Math.max(1f,Math.min(4f,zoom*d.getScaleFactor()));
                    if(getScaleType()!=ScaleType.MATRIX){matrix.set(getImageMatrix());setScaleType(ScaleType.MATRIX);setImageMatrix(matrix);}
                    matrix.postScale(target/zoom,target/zoom,d.getFocusX(),d.getFocusY());zoom=target;setImageMatrix(matrix);return true;
                }
            });
        }
        @Override public void setImageBitmap(Bitmap bm){zoom=1f;setScaleType(ScaleType.FIT_CENTER);super.setImageBitmap(bm);}
        @Override public boolean onTouchEvent(MotionEvent event){
            detector.onTouchEvent(event);
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN:last.set(event.getX(),event.getY());drag=true;return true;
                case MotionEvent.ACTION_POINTER_DOWN:drag=false;return true;
                case MotionEvent.ACTION_MOVE:
                    if(drag&&event.getPointerCount()==1&&zoom>1f){
                        matrix.postTranslate(event.getX()-last.x,event.getY()-last.y);setImageMatrix(matrix);
                        last.set(event.getX(),event.getY());return true;
                    }break;
                case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:drag=false;return true;
                case MotionEvent.ACTION_POINTER_UP:last.set(event.getX(),event.getY());drag=true;return true;
            }
            return true;
        }
    }
}
