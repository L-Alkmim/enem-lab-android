package br.com.enemlab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Main Android application. Local app assets, device-private state, native file picker and PDF reader.
 *  No Edge/Chrome taskbar shortcut, no dependency on an installed browser for the UI. */
public final class MainActivity extends Activity {
    private static final int REQUEST_FILE = 300;
    private static final int REQUEST_SAVE = 301;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingSave;
    private final ExecutorService downloads = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        web.setBackgroundColor(0xff090e1b);
        setContentView(web);
        WebSettings ws=web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setBuiltInZoomControls(false);
        ws.setSupportZoom(false);
        ws.setMediaPlaybackRequiresUserGesture(true);
        ws.setDefaultTextEncodingName("UTF-8");
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.addJavascriptInterface(new DeviceBridge(),"Android");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri u=request.getUrl();
                String scheme=u.getScheme();
                if ("file".equals(scheme) && "android_asset".equals(u.getHost())) return false;
                if ("https".equals(scheme) || "http".equals(scheme)){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){toast("Não foi possível abrir o endereço");}
                    return true;
                }
                return !"file".equals(scheme);
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params){
                if (fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/plain","application/json","application/pdf","application/vnd.ms-excel"});
                try{startActivityForResult(Intent.createChooser(intent,"Selecionar arquivo"),REQUEST_FILE);return true;}
                catch(Exception e){fileCallback=null;callback.onReceiveValue(null);toast("Não foi possível escolher arquivo");return false;}
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    private void toast(String message){runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
    private void js(String code){runOnUiThread(()->{if(web!=null)web.evaluateJavascript(code,null);});}
    private String quoted(String input){return org.json.JSONObject.quote(input);}

    private final class DeviceBridge {
        @JavascriptInterface public void openOfficialPdf(String url,String title){
            try {
                Uri u=Uri.parse(url);
                if(!"https".equals(u.getScheme())||!"download.inep.gov.br".equals(u.getHost())||!url.toLowerCase().endsWith(".pdf")){
                    toast("Somente PDFs oficiais do INEP são permitidos"); return;
                }
                runOnUiThread(()->{
                    Intent i=new Intent(MainActivity.this,PdfViewerActivity.class);
                    i.putExtra("pdfUrl",url);i.putExtra("title",title);
                    startActivity(i);
                });
            } catch(Exception e){toast("Endereço de PDF inválido");}
        }
        @JavascriptInterface public void saveTextFile(String filename,String mime,String content){
            if(filename==null||content==null||content.length()>1500000) {toast("Arquivo grande demais");return;}
            pendingSave=content.getBytes(StandardCharsets.UTF_8);
            String safeName=filename.replaceAll("[^a-zA-Z0-9._-]","_");
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime==null||mime.isEmpty()?"text/plain":mime);
                i.putExtra(Intent.EXTRA_TITLE,safeName);
                try{startActivityForResult(i,REQUEST_SAVE);}catch(Exception e){toast("Não foi possível salvar arquivo");}
            });
        }
        @JavascriptInterface public void fetchTri2025(){
            downloads.execute(()->{
                HttpURLConnection conn=null;
                try{
                    URL url=new URL("https://raw.githubusercontent.com/ProfGabrielRibeiro/MICRODADOS-ENEM/main/dados/ITENS_PROVA_2025.csv");
                    conn=(HttpURLConnection)url.openConnection();
                    conn.setConnectTimeout(12000);conn.setReadTimeout(30000);conn.setInstanceFollowRedirects(false);
                    if(conn.getResponseCode()!=200)throw new IllegalStateException("HTTP "+conn.getResponseCode());
                    ByteArrayOutputStream out=new ByteArrayOutputStream();
                    try(InputStream in=conn.getInputStream()){
                        byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>1200000)throw new IllegalStateException("CSV muito grande");}
                    }
                    String base64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
                    js("window.receiveTri2025("+quoted(base64)+")");
                }catch(Exception e){js("window.triDownloadError("+quoted(e.getMessage()==null?"sem conexão":e.getMessage())+")");}
                finally{if(conn!=null)conn.disconnect();}
            });
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQUEST_FILE){
            if(fileCallback!=null){
                Uri[] uris=result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null;
                fileCallback.onReceiveValue(uris);fileCallback=null;
            }
        }else if(request==REQUEST_SAVE){
            byte[] bytes=pendingSave;pendingSave=null;
            if(result==RESULT_OK&&data!=null&&data.getData()!=null&&bytes!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Sem permissão para escrever");
                    out.write(bytes);toast("Arquivo salvo com sucesso");
                }catch(Exception e){toast("Erro ao salvar: "+e.getMessage());}
            }
        }
    }
    @Override protected void onResume(){super.onResume();if(web!=null)js("window.enemResume?.()");}
    @Override public void onBackPressed(){
        if(web!=null){
            web.evaluateJavascript("(function(){if(document.querySelector('#modalBack')){document.querySelector('#modalBack').click();return true}if(document.body.classList.contains('exam-mode')){document.querySelector('#backBtn')?.click();return true}return false})()",v->{
                if(!"true".equals(v)){new AlertDialog.Builder(this).setMessage("Sair do ENEM Lab?").setNegativeButton("Ficar",(a,b)->{}).setPositiveButton("Sair",(a,b)->finish()).show();}
            });
        } else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        downloads.shutdownNow();
        if(fileCallback!=null){fileCallback.onReceiveValue(null);fileCallback=null;}
        if(web!=null){web.loadUrl("about:blank");web.destroy();web=null;}
        super.onDestroy();
    }
}
