/* ENEM Lab — cálculo por modelo de resposta ao item logístico de três parâmetros (3PL).
   Parâmetros de a, b, c NÃO são inventados. O cálculo só ocorre após importar o
   arquivo ITENS_PROVA_AAAA.csv da edição correspondente, publicado pelo INEP.
   Aproximação EAP N(0,1); escala indicativa 500+100*theta, não nota oficial. */
(function(root){ 'use strict';
 const STORAGE='enem_lab_tri_bases_v3';
 const years=[2022,2023,2024,2025];
 let model={};
 try {model=JSON.parse(root.localStorage?.getItem(STORAGE)||'{}')||{}}catch(e){}
 const num=s=>{const x=Number(String(s??'').trim().replace(',','.'));return Number.isFinite(x)?x:null};
 const clean=s=>String(s??'').trim().replace(/^"|"$/g,'').toUpperCase();
 function rows(csv){
  const lines=csv.replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim());
  if(!lines.length)throw Error('CSV vazio');
  const sep=lines[0].includes(';')?';':',';
  const header=lines[0].split(sep).map(clean);
  const required=['CO_POSICAO','SG_AREA','TX_GABARITO','NU_PARAM_A','NU_PARAM_B','NU_PARAM_C','TX_COR','CO_PROVA','TP_LINGUA'];
  if(required.some(k=>!header.includes(k)))throw Error('Não é um ITENS_PROVA do INEP; faltam colunas de parâmetros.');
  const ix=Object.fromEntries(header.map((k,i)=>[k,i]));
  return lines.slice(1).map(line=>{const col=line.split(sep);const g=k=>clean(col[ix[k]]);const row={
   pos:num(g('CO_POSICAO')), area:g('SG_AREA'), key:g('TX_GABARITO'), a:num(g('NU_PARAM_A')),b:num(g('NU_PARAM_B')),c:num(g('NU_PARAM_C')),
   color:g('TX_COR'), proof:g('CO_PROVA'), lang:g('TP_LINGUA'), dropped:g('IN_ITEM_ABAN')==='1', adapted:g('IN_ITEM_ADAPTADO')==='1'
  };return row}).filter(r=>r.color==='AZUL'&&r.pos>=1&&r.pos<=180&&r.proof&&r.area&&['A','B','C','D','E','X'].includes(r.key));
 }
 function area(code){return {LG:'LC',CH:'CH',CN:'CN',MT:'MT'}[code]}
 function candidates(recs,ex,code,lang){
  const areaName=area(code),day=ex.day,lo=code==='LG'?1:code==='CH'?46:code==='CN'?91:136;
  const official=ex.day===1&&lang==='es'?ex.spanish:ex.key;
  let group={};
  for(const r of recs){if(r.area!==areaName||r.adapted)continue;
   const offset=r.pos>=lo&&r.pos<lo+45?lo:((r.pos>=1&&r.pos<=45)?1:null);
   if(offset===null)continue;
   const pos=lo+(r.pos-offset),index=pos-(day===1?1:91),key=official[index];
   if(index<0||index>=90||!key)continue;
   const id=r.proof+'|'+r.lang+'|'+offset;
   if(!group[id])group[id]={matches:0,compared:0,map:[],lang:r.lang};
   const g=group[id];
   if(key!=='X'&&r.key!=='X'){g.compared++;if(key===r.key)g.matches++}
   if(r.key===key&&Number.isFinite(r.a)&&r.a>0&&Number.isFinite(r.b)&&r.c>=0&&r.c<1&&!r.dropped){g.map[index-(code==='LG'||code==='CN'?0:45)]=[r.a,r.b,r.c]}
  }
  return Object.values(group).sort((a,b)=>(b.matches-b.compared*0.15)-(a.matches-a.compared*0.15));
 }
 function build(recs,exams,year){
  const output={year,updated:new Date().toISOString(),exams:{}};
  for(const ex of exams.filter(x=>x.year===year)){
   output.exams[ex.id]={};
   for(const lang of ex.day===1?['en','es']:['en']){
    const map={};
    for(const code of (ex.day===1?['LG','CH']:['CN','MT'])){
      let rank=candidates(recs,ex,code,lang).filter(x=>x.compared>=28&&x.matches/x.compared>=0.90);
      if(!rank.length)continue;
      // Para LC, a opção de língua estrangeira usa gabaritos distintos nos 5 primeiros itens.
      if(code==='LG')rank.sort((a,b)=> ((b.lang===(lang==='es'?'1':'0'))?1:0)-((a.lang===(lang==='es'?'1':'0'))?1:0) || b.matches-a.matches);
      let best=rank[0];
      const valid=best.map.filter(Boolean).length;
      if(valid>=35)map[code]={items:best.map,coverage:valid,match:best.matches,compared:best.compared};
    }
    output.exams[ex.id][lang]=map;
   }
  }
  if(!Object.values(output.exams).some(v=>Object.values(v).some(x=>Object.keys(x).length))) throw Error('As questões do CSV não coincidem com os gabaritos das provas azuis. Confira o ano e o arquivo.');
  return output;
 }
 function importCsv(year,csv,exams){
  year=Number(year);
  if(!years.includes(year))throw Error('Ano fora da biblioteca (2022–2025).');
  if(!csv||csv.length<100)throw Error('Arquivo CSV incompleto');
  const parsed=rows(csv),dataset=build(parsed,exams,year);
  model[year]=dataset;
  try{root.localStorage?.setItem(STORAGE,JSON.stringify(model))}catch(e){delete model[year];throw Error('Espaço de armazenamento insuficiente. Faça backup e libere espaço.')}
  return status(year);
 }
 function status(year){
  const d=model[year];if(!d)return{loaded:false,areas:0};
  let areas=0;for(const exam of Object.values(d.exams||{}))for(const list of Object.values(exam))areas+=Object.keys(list).length;
  return{loaded:true,areas,updated:d.updated};
 }
 function parameters(ex,code,lang){return model[ex.year]?.exams?.[ex.id]?.[ex.day===1?lang:'en']?.[code]||null}
 // A posteriori esperado (EAP). Integral numérica robusta em grade de theta [-4.5,4.5], passo 0,05,
 // log-verossimilhança 3PL e priori normal padrão. Não é o software de estimação do Inep.
 function eap(answerBits,params){
  if(answerBits.length!==params.length||answerBits.length<30)return null;
  const n=181,delta=0.05,start=-4.5,logs=[];
  for(let j=0;j<n;j++){
   const theta=start+j*delta;let logp=-theta*theta/2;
   for(let i=0;i<params.length;i++){
    const [a,b,c]=params[i];
    const z=Math.max(-35,Math.min(35,1.7*a*(theta-b)));
    const p=Math.min(1-1e-13,Math.max(1e-13,c+(1-c)/(1+Math.exp(-z))));
    logp+=answerBits[i]?Math.log(p):Math.log1p(-p);
   }
   logs.push(logp);
  }
  const peak=Math.max(...logs);let sum=0,sumTheta=0;
  for(let j=0;j<n;j++){
   const w=Math.exp(logs[j]-peak)*(j===0||j===n-1?1:j%2===0?2:4);const theta=start+j*delta;
   sum+=w;sumTheta+=theta*w;
  }
  return sum?sumTheta/sum:null;
 }
 function score(ex,s,code,key){
  const ds=parameters(ex,code,s.lang);
  if(!ds)return{estimated:null,source:'missing-base',coverage:0};
  const offset=code==='LG'||code==='CN'?0:45;let bits=[],params=[],count=0;
  for(let j=0;j<45;j++){
   const i=offset+j;
   if(key[i]==='X')continue;
   count++;
   if(!ds.items[j])return{estimated:null,source:'incomplete-parameters',coverage:ds.coverage,total:count};
   params.push(ds.items[j]);bits.push(s.answers[i]===key[i]?1:0);
  }
  const theta=eap(bits,params);
  return {estimated:theta===null?null:Math.round(500+100*theta),theta,source:'INEP-3PL-EAP',coverage:params.length};
 }
 function forget(year){delete model[year];root.localStorage?.setItem(STORAGE,JSON.stringify(model))}
 root.TriLab={importCsv,score,status,forget,eap,rows,candidates,parameters};
})(typeof window!=='undefined'?window:globalThis);
