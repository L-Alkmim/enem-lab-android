const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const script=fs.readFileSync(__dirname+'/../app/src/main/assets/tri-engine.js','utf8');
const store={};const root={localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v}};
vm.runInNewContext(script,{window:root,console});
const engine=root.TriLab;
const params=Array.from({length:45},(_,i)=>[1.5,-1+i/22,0.15]);
function estimate(bits){return engine.eap(bits,params)}
assert(estimate(Array(45).fill(1))>estimate(Array(45).fill(0)),'More correct answers should increase proficiency');
assert(Number.isFinite(estimate(Array(45).fill(1))));
assert(Number.isFinite(estimate(Array(45).fill(0))));
assert(engine.status(2025).loaded===false,'No fabricated source data');
assert.throws(()=>engine.importCsv(2025,'bad csv',[]));
// Simulate official item data for 2025, blue day 2, with 90 items from two 45-item areas.
const key='ABCDE'.repeat(18);
const exam={year:2025,id:'2025-d2',day:2,key};
let csv='CO_POSICAO;SG_AREA;CO_ITEM;TX_GABARITO;CO_HABILIDADE;IN_ITEM_ABAN;TX_MOTIVO_ABAN;NU_PARAM_A;NU_PARAM_B;NU_PARAM_C;TX_COR;CO_PROVA;TP_LINGUA;IN_ITEM_ADAPTADO\n';
for(let i=0;i<90;i++)csv+=`${91+i};${i<45?'CN':'MT'};${1000+i};${key[i]};2;0;;1.5;${(-1+i/45).toFixed(3)};0.15;AZUL;1460;0;0\n`;
const status=engine.importCsv(2025,csv,[exam]);
assert(status.areas===2,'Should load two matching areas');
const a={lang:'en',answers:key.split('')};
const result=engine.score(exam,a,'CN',key);
assert(result.source==='INEP-3PL-EAP');
assert(result.estimated>500,'All correct answers must score above prior mean');
const worse={lang:'en',answers:Array(90).fill('Z')};
assert(engine.score(exam,worse,'CN',key).estimated<result.estimated);
assert(engine.score({...exam,year:2024},a,'CN',key).estimated===null,'Missing base produces no score');
console.log('PASS: TRI 3PL EAP, base validation, item mapping, missing data safeguards');
